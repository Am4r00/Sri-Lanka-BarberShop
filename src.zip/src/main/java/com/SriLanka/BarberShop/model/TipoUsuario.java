package com.SriLanka.BarberShop.model;

public enum TipoUsuario {
    CLIENTE, BARBEIRO, BARBEIRO_ADMIN
}