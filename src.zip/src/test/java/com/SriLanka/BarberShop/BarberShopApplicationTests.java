package com.SriLanka.BarberShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarberShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
